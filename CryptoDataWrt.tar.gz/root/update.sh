#!/bin/sh
/usr/bin/wget -q -O - "https://raw.githubusercontent.com/cryptodata-com/xiden-guardian-updater/master/update-script.sh" | /bin/ash
